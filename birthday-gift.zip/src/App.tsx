import React, { useState, useEffect, useRef } from 'react';
import { Heart, Music, Sparkles, Smartphone, LogIn } from 'lucide-react';

/**
 * Interface for floating heart particles on click
 */
interface HeartParticle {
  id: number;
  x: number;
  y: number;
  dx: number;
  dy: number;
  rotation: number;
  scale: number;
  duration: number;
}

export default function App() {
  // Application interaction steps:
  // 1: شلونج ملاكي؟ (زينة)
  // 2: اليوم تاريخ ميلاد منو؟ (ميلادي)
  // 3: اذا تحبيني دوسي القلب 🤍 (Click CSS heart)
  // 4: غدير.. عبالج نسيت تاريخ اليوم... (استمعي للأغنية 🎵)
  const [step, setStep] = useState<number>(1);
  
  // Typewriter effect state
  const [typedText, setTypedText] = useState<string>("");
  const [typingComplete, setTypingComplete] = useState<boolean>(false);
  
  // Particle effects state
  const [particles, setParticles] = useState<HeartParticle[]>([]);
  const particleIdCounter = useRef<number>(0);

  // PWA install prompt handler
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState<boolean>(false);

  // Full texts for Syrian/Iraqi romantic dialect requested by user
  const questions: Record<number, string> = {
    1: "شلونج ملاكي؟",
    2: "اليوم تاريخ ميلاد منو؟",
    3: "إذا تحبيني دوسي القلب 🤍",
    4: "غدير.. عبالج نسيت تاريخ اليوم الي انولدت بي أحلى بنية؟ أموت عليج"
  };

  // Run typewriter effect when step changes
  useEffect(() => {
    // Reset active elements and animations when moving step-by-step
    setParticles([]);
    let activeText = questions[step] || "";
    setTypedText("");
    setTypingComplete(false);
    
    let index = 0;
    // Set variable speeds: final step has longer text so we type faster
    const typingSpeed = step === 4 ? 40 : 70;
    
    const interval = setInterval(() => {
      setTypedText((prev) => prev + activeText.charAt(index));
      index++;
      if (index >= activeText.length) {
        clearInterval(interval);
        setTypingComplete(true);
      }
    }, typingSpeed);

    return () => clearInterval(interval);
  }, [step]);

  // React to PWA installation prompts
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  // Install PWA application handler
  const handleInstallApp = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstallable(false);
    }
    setDeferredPrompt(null);
  };

  // Generate beautiful floating heart particles on tapping the CSS heart
  const triggerHeartBurst = (e: React.MouseEvent<HTMLDivElement>) => {
    const cardElement = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - cardElement.left;
    const clickY = e.clientY - cardElement.top;

    const newParticles: HeartParticle[] = Array.from({ length: 15 }).map(() => {
      particleIdCounter.current += 1;
      const angle = Math.random() * Math.PI * 2;
      const velocity = Math.random() * 80 + 35; // Distance radius
      const dx = Math.cos(angle) * velocity;
      const dy = Math.sin(angle) * velocity - 50; // Vertical lift upwards bias
      const rotation = Math.random() * 240 - 120;
      const scale = Math.random() * 0.8 + 0.5;
      const duration = Math.random() * 0.4 + 0.8; // 0.8s to 1.2s

      return {
        id: particleIdCounter.current,
        x: clickX,
        y: clickY,
        dx,
        dy,
        rotation,
        scale,
        duration,
      };
    });

    setParticles(newParticles);

    // Play subtle audio synthetic pop if API allows, to increase immersion
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        const audioCtx = new AudioContextClass();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, audioCtx.currentTime); // A4
        osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.1); // Sparkle slide
        gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.15);
      }
    } catch (err) {
      // Ignored if browser policy blocks instant audioctx initialization
    }

    // Advance to final text screen after a romantic delay to view sparkles
    setTimeout(() => {
      setStep(4);
    }, 1200);
  };

  return (
    <main className="relative flex flex-col items-center justify-center min-h-screen w-full bg-[#0d1412] text-white font-sans overflow-hidden px-4 select-none">
      
      {/* Decorative Interactive Background Layers */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        {/* Deep forest premium glows */}
        <div id="orb-1" className="absolute -top-12 -left-12 w-80 h-80 bg-[#1b2622] rounded-full blur-[80px] opacity-40 animate-float-slow"></div>
        <div id="orb-2" className="absolute -bottom-20 -right-20 w-96 h-96 bg-[#2a3b35] rounded-full blur-[90px] opacity-35 animate-float-reverse"></div>
        <div id="orb-3" className="absolute top-1/3 left-1/2 -translate-x-1/2 w-72 h-72 bg-[#101917] rounded-full blur-[100px] opacity-50"></div>
        
        {/* Cute micro gold star sparkles drifting in background */}
        <div className="absolute top-12 left-1/4 w-1 h-1 bg-[#e2b474] rounded-full opacity-60 animate-pulse"></div>
        <div className="absolute top-1/3 right-1/4 w-1.5 h-1.5 bg-[#e2b474] rounded-full opacity-40 animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-12 left-1/3 w-1.5 h-1.5 bg-white rounded-full opacity-30 animate-pulse" style={{ animationDelay: '2.5s' }}></div>
        <div className="absolute bottom-1/4 right-12 w-1 h-1 bg-[#e2b474] rounded-full opacity-50 animate-pulse" style={{ animationDelay: '1.8s' }}></div>
      </div>

      {/* PWA Direct Installation Banner for iOS/Android if available */}
      {isInstallable && (
        <button
          id="btn-pwa-install"
          onClick={handleInstallApp}
          className="absolute top-4 sm:top-6 z-30 flex items-center gap-2 bg-[#1b2622]/80 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 text-xs text-[#e2b474] font-medium active:scale-95 shadow-md hover:bg-[#2a3b35]/80 transition-all cursor-pointer animate-pop-in duration-500"
        >
          <Smartphone size={14} className="animate-bounce" />
          <span>تثبيت التطبيق على الشاشة الرئيسية 📱</span>
        </button>
      )}

      {/* PERFECTLY SQUARE CARD CONTAINER (260x260px) centered exactly */}
      <div 
        id="birthday-gift-card"
        className="relative z-10 w-[260px] h-[260px] rounded-3xl p-5 flex flex-col justify-between items-center text-center glass-panel select-none overflow-hidden animate-pop-in"
      >
        
        {/* Click floating hearts burst overlay using high-performance CSS hardware animations */}
        {particles.map((p) => (
          <span
            key={p.id}
            className="absolute text-rose-500 pointer-events-none font-bold select-none text-lg drop-shadow-sm animate-heart-particle"
            style={{
              left: `${p.x}px`,
              top: `${p.y}px`,
              '--dx': `${p.dx}px`,
              '--dy': `${p.dy}px`,
              '--rot': `${p.rotation}deg`,
              '--scale': p.scale,
              '--dur': `${p.duration}s`,
              textShadow: '0 0 8px rgba(244,63,94,0.4)'
            } as React.CSSProperties}
          >
            ❤
          </span>
        ))}

        {/* Step 1 Content: شلونج ملاكي؟ */}
        {step === 1 && (
          <div className="flex flex-col justify-between items-center w-full h-full py-1">
            <span className="text-xs font-mono text-[#e2b474]/70 uppercase tracking-widest neon-glow">Mylady 👑</span>
            
            <div className="flex-1 flex items-center justify-center px-1">
              <h2 className="text-[20px] font-bold text-white font-cairo leading-snug tracking-tight">
                <span className="typewriter-cursor">{typedText}</span>
              </h2>
            </div>
            
            <button
              id="btn-step-1"
              onClick={() => setStep(2)}
              disabled={!typingComplete}
              className={`w-full py-2.5 rounded-2xl text-sm font-semibold font-cairo shadow-inner glass-button text-white flex items-center justify-center gap-1.5 cursor-pointer ${
                !typingComplete ? 'opacity-40 cursor-default pointer-events-none' : 'opacity-100'
              }`}
            >
              <span>زينة</span>
              <Sparkles size={14} className="text-[#e2b474]" />
            </button>
          </div>
        )}

        {/* Step 2 Content: اليوم تاريخ ميلاد منو؟ */}
        {step === 2 && (
          <div className="flex flex-col justify-between items-center w-full h-full py-1">
            <span className="text-xs font-mono text-[#e2b474]/70 uppercase tracking-widest neon-glow">Specials ✨</span>
            
            <div className="flex-1 flex items-center justify-center px-1">
              <h2 className="text-[19px] font-bold text-white font-cairo leading-snug tracking-tight">
                <span className="typewriter-cursor">{typedText}</span>
              </h2>
            </div>
            
            <button
              id="btn-step-2"
              onClick={() => setStep(3)}
              disabled={!typingComplete}
              className={`w-full py-2.5 rounded-2xl text-sm font-semibold font-cairo glass-button text-white flex items-center justify-center gap-1.5 cursor-pointer ${
                !typingComplete ? 'opacity-40 cursor-default pointer-events-none' : 'opacity-100'
              }`}
            >
              <span>ميلادي 🎂</span>
            </button>
          </div>
        )}

        {/* Step 3 Content: دوسي القلب 🤍 */}
        {step === 3 && (
          <div className="flex flex-col justify-between items-center w-full h-full py-1">
            {/* Header prompt instruction */}
            <h3 className="text-[14px] px-1 font-semibold text-white/95 font-cairo tracking-tight leading-tight select-none">
              <span className="typewriter-cursor">{typedText}</span>
            </h3>

            {/* Glowing Intersecting Thread Lines CSS Heart (خيوط) with Breathing pulse effect */}
            <div 
              id="interactable-love-heart"
              onClick={triggerHeartBurst}
              className="relative w-20 h-20 flex items-center justify-center cursor-pointer group active:scale-90 transition-transform duration-150 select-none my-1"
              title="دوسي اهنا 🤍"
            >
              {/* Overlapping glowing vector strokes representing the yarn/threads style (خيوط) */}
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                className="w-16 h-16 animate-pulse-heart select-none"
              >
                <defs>
                  {/* Glowing gradients */}
                  <linearGradient id="heartGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#ffffff" />
                    <stop offset="60%" stopColor="#e2b474" />
                    <stop offset="100%" stopColor="#bf924e" />
                  </linearGradient>
                  
                  <linearGradient id="innerThread" x1="100%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#f43f5e" />
                    <stop offset="100%" stopColor="#ec4899" />
                  </linearGradient>

                  <filter id="glow-effect" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="3" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>

                {/* Layer 1: Outermost glow path */}
                <path 
                  d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" 
                  stroke="url(#heartGrad)" 
                  strokeWidth="1.2" 
                  strokeDasharray="3,1"
                  className="opacity-75"
                />

                {/* Layer 2: Middle overlapping yarn/thread details */}
                <path 
                  d="M12 19.6l-1.15-1.05C6.1 14.36 3.2 11.5 3.2 8.5c0-2.3 1.8-4.1 4.1-4.1 1.4 0 2.8.7 3.7 1.8.9-1.1 2.3-1.8 3.7-1.8 2.3 0 4.1 1.8 4.1 4.1 0 3-2.9 5.86-7.65 10.05L12 19.6z" 
                  stroke="url(#heartGrad)" 
                  strokeWidth="1" 
                  strokeDasharray="1,2"
                />

                {/* Layer 3: Solid highly glowing heart core */}
                <path 
                  d="M12 17.5l-.85-.78C6.9 13.05 4.5 10.5 4.5 8.5c0-1.6 1.3-2.9 2.9-2.9 1.1 0 2.2.6 2.8 1.5.6-.9 1.7-1.5 2.8-1.5 1.6 0 2.9 1.3 2.9 2.9 0 2-2.4 4.55-6.65 8.22L12 17.5z" 
                  fill="url(#heartGrad)" 
                  fillOpacity="0.8"
                  filter="url(#glow-effect)"
                  className="transition-transform group-hover:scale-105"
                />
              </svg>
              
              {/* Interactive micro prompt helper */}
              <span className="absolute -bottom-1 text-[10px] font-semibold text-[#e2b474] font-cairo tracking-wide animate-pulse">
                دوسي هنا 🤍
              </span>
            </div>

            {/* Bottom mini status label */}
            <span className="text-[9px] font-mono text-white/40 tracking-wider">Tap to express love</span>
          </div>
        )}

        {/* Step 4 Content: الرسالة النهائية مع زر استماع الاغنية */}
        {step === 4 && (
          <div className="flex flex-col justify-between items-center w-full h-full py-1">
            <span className="text-xs font-mono text-[#e2b474]/90 uppercase tracking-widest neon-glow">Always & Forever 🤍</span>
            
            {/* Middle beautiful narrative message with compact spacing to avoid clipping */}
            <div className="flex-1 flex items-center justify-center my-1">
              <p className="text-[14px] font-medium text-white/90 font-cairo leading-relaxed tracking-normal text-center select-none max-h-[125px] overflow-y-auto px-1">
                <span className="typewriter-cursor select-none">{typedText}</span>
              </p>
            </div>
            
            <a
              id="btn-step-4-song"
              href="https://youtu.be/3YxaaGgTQYM?si=LIYIsqHo6nRV6ZSR"
              target="_blank"
              rel="noopener noreferrer"
              className={`w-full py-2.5 rounded-2xl text-sm font-semibold font-cairo bg-gradient-to-r from-[#e2b474] to-[#cba063] hover:from-[#f3ca8f] hover:to-[#dfb578] text-black hover:text-black flex items-center justify-center gap-1.5 cursor-pointer shadow-lg active:scale-95 transition-all outline-none border-none text-center justify-center items-center select-none decoration-none no-underline ${
                !typingComplete ? 'opacity-40 cursor-default pointer-events-none' : 'opacity-100'
              }`}
            >
              <span>استمعي للأغنية 🎵</span>
              <Music size={14} className="animate-spin-slow text-black" style={{ animationDuration: '3s' }} />
            </a>
          </div>
        )}

      </div>

      {/* Footer copyright label styled with humility and high visual polish */}
      <footer className="absolute bottom-6 z-10 text-[10px] font-mono text-white/30 tracking-tight text-center pointer-events-none">
        <span>Ghadir’s Day 🤍 Crafted For Ghadir</span>
      </footer>

    </main>
  );
}
